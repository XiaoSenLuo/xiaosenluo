/**
*参考Arduino-LiquidCrystal lib
*
*
**/

#include "hard_device.h"
#include "LCDxxxx.h"
#include <stdio.h>
#include <string.h>

static void LCD_send(unsigned char value, unsigned char mode);
static void LCD_write4bits(unsigned char value);
static void LCD_write8bits(unsigned char value);
static void LCD_pulseEnable();

#define DP				P2

sbit LCD_RS = P1^0;
sbit LCD_RW = P1^1;
sbit LCD_EN = P1^2;

static unsigned char displayFunction;
static unsigned char displayControl;
static unsigned char displayMode;

//static volatile unsigned char initialized;
static unsigned char lcdCol;
static unsigned char numLines;
static unsigned char rowOffsets[4];

void LCD_Init(unsigned char fourbitmode){
	if(fourbitmode)
    displayFunction = LCD_4BITMODE | LCD_1LINE | LCD_5x8DOTS;
  else 
    displayFunction = LCD_8BITMODE | LCD_1LINE | LCD_5x8DOTS;
  
  LCD_Begin(16, 1);  
}
    
void LCD_Begin(unsigned char cols, unsigned char lines){
  unsigned char dotsize=LCD_5x8DOTS;
	pinInit(0, 0, PIN_MODE_OP);
	portInit(1);
	portInit(2);
  if (lines > 1) {
    displayFunction |= LCD_2LINE;
  }
  numLines = lines;
	lcdCol=cols;
  LCD_SetRowOffsets(0x00, 0x40, 0x00 + cols, 0x40 + cols);  

  // for some 1 line displays you can select a 10 pixel high font
  if ((dotsize != LCD_5x8DOTS) && (lines == 1)) {
    displayFunction |= LCD_5x10DOTS;
  }
  // SEE PAGE 45/46 FOR INITIALIZATION SPECIFICATION!
  // according to datasheet, we need at least 40ms after power rises above 2.7V
  // before sending commands. Arduino can turn on way before 4.5V so we'll wait 50
  Delay_ms(5); 
	LCD_RS=0;
	LCD_EN=0;
  LCD_RW=0;
  //put the LCD into 4 bit or 8 bit mode
  if (!(displayFunction & LCD_8BITMODE)){
    // this is according to the hitachi HD44780 datasheet
    // figure 24, pg 46
    // we start in 8bit mode, try to set 4 bit mode
    LCD_write4bits(0x03);
//    delayMicroseconds(4500); // wait min 4.1ms
		Delay_us(4500);
    // second try
    LCD_write4bits(0x03);
//    delayMicroseconds(4500); // wait min 4.1ms
    Delay_us(4500);
    // third go!
    LCD_write4bits(0x03); 
//    delayMicroseconds(150);
		Delay_us(150);
    // finally, set to 4-bit interface
    LCD_write4bits(0x02); 
  }else{
    // this is according to the hitachi HD44780 datasheet
    // page 45 figure 23

    // Send function set command sequence
    LCD_Command(LCD_FUNCTIONSET | displayFunction);
//    delayMicroseconds(4500);  // wait more than 4.1ms
		Delay_us(4500);
    // second try
    LCD_Command(LCD_FUNCTIONSET | displayFunction);
//    delayMicroseconds(150);
		Delay_us(150);
    // third go
    LCD_Command(LCD_FUNCTIONSET | displayFunction);
  }

  // finally, set # lines, font size, etc.
  LCD_Command(LCD_FUNCTIONSET | displayFunction);  

  // turn the display on with no cursor or blinking default
  displayControl = LCD_DISPLAYON | LCD_CURSOROFF | LCD_BLINKOFF;  
  LCD_Display();

  // clear it off
  LCD_Clear();

  // Initialize to default text direction (for romance languages)
  displayMode = LCD_ENTRYLEFT | LCD_ENTRYSHIFTDECREMENT;
  // set the entry mode
  LCD_Command(LCD_ENTRYMODESET | displayMode);
}

/********** high level commands, for the user! */
void LCD_DisplayChr(unsigned char col, unsigned char row, unsigned char value){
	LCD_SetCursor(col,row);
	LCD_Write(value);
}
void LCD_DisplayStr(unsigned char col, unsigned char row, unsigned char code* str){
//	unsigned char len=0;
//	col &= 0xf;
//	row &= 0x1;
//	while(str[len]>=0x20){
//		if(col<=0xf){
//			LCD_DisplayChr(col, row, str[len]);
//			len++;
//			col++;
//			//Delay_us(10);
//		}
//	}

	unsigned char i=0;
	while(str[i]>=0x20){
		LCD_DisplayChr(col+i, row, str[i]);
		Delay_us(10);
		if(i>(lcdCol-col) && ((numLines-row)>=1)){
			LCD_DisplayChr((i-lcdCol+col-1), row+1, str[i]);
			Delay_us(10);
		}
		i++;
	}
}

void LCD_Clear(void){
  LCD_Command(LCD_CLEARDISPLAY);  // clear display, set cursor position to zero
  Delay_us(2000);  // this command takes a long time!	
}
void LCD_Home(void){
  LCD_Command(LCD_RETURNHOME);  // set cursor position to zero
	Delay_us(2000);  					// this command takes a long time!	
}

void LCD_NoDisplay(void){
  displayControl &= ~LCD_DISPLAYON;
  LCD_Command(LCD_DISPLAYCONTROL | displayControl);	
}
void LCD_Display(void){
  displayControl |= LCD_DISPLAYON;
  LCD_Command(LCD_DISPLAYCONTROL | displayControl);	
}
void LCD_NoBlink(void){
  displayControl &= ~LCD_BLINKON;
  LCD_Command(LCD_DISPLAYCONTROL | displayControl);	
}
void LCD_Blink(void){
  displayControl |= LCD_BLINKON;
  LCD_Command(LCD_DISPLAYCONTROL | displayControl);	
}
void LCD_NoCursor(void){
  displayControl &= ~LCD_CURSORON;
  LCD_Command(LCD_DISPLAYCONTROL | displayControl);	
}
void LCD_Cursor(void){
  displayControl |= LCD_CURSORON;
  LCD_Command(LCD_DISPLAYCONTROL | displayControl);	
}
void LCD_ScrollDisplayLeft(void){
	LCD_Command(LCD_CURSORSHIFT | LCD_DISPLAYMOVE | LCD_MOVELEFT);
}
void LCD_ScrollDisplayRight(void){
	LCD_Command(LCD_CURSORSHIFT | LCD_DISPLAYMOVE | LCD_MOVERIGHT);
}
void LCD_LeftToRight(void){
  displayMode |= LCD_ENTRYLEFT;
  LCD_Command(LCD_ENTRYMODESET | displayMode);	
}
void LCD_RightToLeft(void){
  displayMode &= ~LCD_ENTRYLEFT;
  LCD_Command(LCD_ENTRYMODESET | displayMode);	
}
void LCD_AutoScroll(void){
	displayMode &= ~LCD_ENTRYLEFT;
  LCD_Command(LCD_ENTRYMODESET | displayMode);
}
void LCD_NoAutoScroll(void){
	displayMode&=~LCD_ENTRYSHIFTINCREMENT;
	LCD_Command(LCD_ENTRYMODESET | displayMode);
}

void LCD_SetRowOffsets(int row1, int row2, int row3, int row4){
	rowOffsets[0]=row1;
	rowOffsets[1]=row2;
	rowOffsets[2]=row3;
	rowOffsets[3]=row4;
}
void LCD_CreateChar(unsigned char location, unsigned char charmap[]){
	int i;
	location &= 0x7;
	LCD_Command(LCD_SETCGRAMADDR | (location << 3));
	for(i=0;i<8;i++)
		LCD_Write(charmap[i]);
}
void LCD_SetCursor(unsigned char col, unsigned char row){
	const unsigned char maxLines=sizeof(rowOffsets)/sizeof(*rowOffsets);
	if(row>=maxLines) row=maxLines-1;
	if(row>=numLines) row=numLines-1;
	LCD_Command(LCD_SETDDRAMADDR | (col + rowOffsets[row]));
}
/*********** mid level commands, for sending data/cmds */
void LCD_Command(unsigned char value){
	LCD_send(value, W_COMMAND);
}
char LCD_Write(unsigned char value){
	LCD_send(value, W_DATA);
	return 1;
}
/************ low level data pushing commands **********/
static void LCD_send(unsigned char value, unsigned char mode){
	LCD_RW=1;
	Delay_us(10);
	LCD_RS=mode;
	LCD_RW=0;
	if(displayFunction&LCD_8BITMODE){
		LCD_write8bits(value);
	}else{
		LCD_write4bits((value));
		LCD_write4bits(value<<4);
	}
	LCD_RW=1;
	LCD_RS=(!mode);
}
static void LCD_write4bits(unsigned char value){
	DP=value&0xf0;
	LCD_pulseEnable();
}
static void LCD_write8bits(unsigned char value){
	DP=value&0xff;
	LCD_pulseEnable();
}
static void LCD_pulseEnable(void){
	LCD_EN=0;
	Delay_us(10);
	LCD_EN=1;
	Delay_us(10);
	LCD_EN=0;
	Delay_us(10);
//	LCD_EN=1;
}

/*  经测试，读取状态一直为忙，程序会死在这里 */
unsigned char LCD_ReadStatus(void){
	unsigned char status;
	DP=0xff;
	LCD_RS=0;
	LCD_RW=1;
	Delay_us(10);
	LCD_EN=0;
	Delay_us(10);
	LCD_EN=1;	
	Delay_us(10);
	LCD_EN=0;
	status=DP;
	Delay_us(10);
	while((status & 0x80));
	return (status);
}
