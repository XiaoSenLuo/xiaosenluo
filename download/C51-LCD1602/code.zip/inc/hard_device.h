

#include "STC12C5A60S2.h"
#include <intrins.h>


#define SYSTEM_COLCK								115200000

#define STC_OK											0x00
#define STC_ERROR										0x01

#define PIN_MODE_WP									0x00
#define PIN_MODE_OP									0x01
#define PIN_MODE_IP									0x02
#define PIN_MODE_OD									0x04

#define UART_MODE_0									0x00
#define UART_MODE_1									0x01
#define UART_MODE_2									0x02
#define UART_MODE_3									0x04
#define UART1												0x01
#define UART2												0x02

void Delay_us(unsigned int us);
void Delay_ms(unsigned int ms);
void pinInit(unsigned char port, unsigned char pin, unsigned char mode);
void portInit(unsigned char port);

