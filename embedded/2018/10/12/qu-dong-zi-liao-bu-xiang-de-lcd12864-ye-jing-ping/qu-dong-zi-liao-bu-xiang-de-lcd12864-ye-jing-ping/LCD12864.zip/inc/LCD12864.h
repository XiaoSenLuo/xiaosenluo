/*
 *������ST7565

*/

// flags for display on/off control
#define LCD_DISPLAY_ON 							0xAF
#define LCD_DISPLAY_OFF 						0xAE
#define LCD_DISPLAY_NORMAL					0xA6
#define LCD_DISPLAY_REVERSE					0xA7
#define LCD_DISPLAY_ALL_POINT_ON		0xA5
#define LCD_DISPLAY_ALL_POINT_OFF		0xA4
#define LCD_DISPLAY_START_LINE			0x40


#define LCD_SET_PAGE_ADDR						0xB0
#define LCD_SET_COLUMN_H						0x10
#define LCD_SET_COLUMN_L						0x00

#define LCD_SELECT_ADC_NORMAL				0xA0
#define LCD_SELECT_ADC_REVERSR			0xA1

#define LCD_SET_BIAS								0xA2
#define LCD_BIAS_1_9								0x00
#define LCD_BIAS_1_7								0x01

#define LCD_READ_MODIFY_WRITE				0xE0

#define LCD_END											0xEE

#define LCD_RESET										0xE2

#define LCD_SELECT_COM_OUTPUT_MODE	0xC0
#define LCD_COM_OUTPUT_MODE_NOR			0x00
#define LCD_COM_OUTPUT_MODE_REV			0x08

#define LCD_SET_POWER_CONTROL				0x28
#define LCD_BOOSTER_CIRCUIT_OFF			0x00
#define LCD_BOOSTER_CIRCUIT_ON			0x04
#define LCD_VOL_REG_CIRCUIT_OFF			0x00
#define LCD_VOL_REG_CIRCUIT_ON			0x02
#define LCD_VOL_FOL_CIRCUIT_OFF			0x00
#define LCD_VOL_FOL_CIRCUIT_ON			0x01

#define LCD_SET_VOL_MODE						0x81
#define LCD_NO_USE_VOL_MODE					0x20

#define LCD_SET_SLEEP_MODE					0xAC
#define LCD_SLEEP_MODE							0x00
#define LCD_NORMAL_MODE							0x01
#define LCD_SLEEP_FOL_COMM					0x00

#define LCD_SET_BOOSTER_RATIO


#define LCD_NOP											0xE3
#define LCD_TEST										0xF0

#define LOW										0
#define HIGH									1

#define W_COMMAND							0
#define W_DATA								1

#define R_DATA								1
#define R_STATUS							0


void LCD_Init(void);
    
void LCD_Begin(unsigned char cols, unsigned char lines);

void LCD_Clear(void);
void LCD_Home(void);

void LCD_DisplayChr(unsigned char col, unsigned char row, unsigned char value);
void LCD_DisplayStr(unsigned char col, unsigned char row, unsigned char code* str);

void LCD_NoDisplay(void);
void LCD_Display(void);
void LCD_NoBlink(void);
void LCD_Blink(void);
void LCD_NoCursor(void);
void LCD_CcrollDisplayLeft(void);
void LCD_ScrollDisplayRight(void);
void LCD_LeftToRight(void);
void LCD_RightToLeft(void);
void LCD_AutoScroll(void);
void LCD_NoAutoScroll(void);

void LCD_SetRowOffsets(int row1, int row2, int row3, int row4);
void LCD_CreateChar(unsigned char location, unsigned char charmap[]);
void LCD_SetCursor(unsigned char col, unsigned char row); 
void LCD_Command(unsigned char value);
char LCD_Write(unsigned char value);


