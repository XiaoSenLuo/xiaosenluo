

#include "hard_device.h"
//#include "STC12C5A60S2.h"
#include "main.h"
#include "LCD12864.h"

unsigned char code t[]="test,LCD!";
	
void main(void){
	unsigned char i,len=sizeof(t);

	P00=0;
	Delay_ms(1000);
	P00=1;
	LCD_Init();
//	LCD_DisplayChr(0, 0, 'A');
//	Delay_ms(100);
//	LCD_DisplayChr(1, 0, 'B');
//		Delay_ms(100);
//	LCD_DisplayChr(2, 0, 'C');
//		Delay_ms(100);
//	LCD_DisplayChr(3, 0, 'D');
//		Delay_ms(100);
//	LCD_DisplayChr(4, 0, 'E');
//			Delay_ms(100);
//	LCD_DisplayChr(0, 1, 'F');
//			Delay_ms(100);
//	LCD_DisplayChr(1, 1, 'G');
//	LCD_DisplayStr(0, 1, t);							//ͨ��
////	LCD_DisplayStr(0, 1, "test,LCD!";		//ͨ��
	while(1);
}
