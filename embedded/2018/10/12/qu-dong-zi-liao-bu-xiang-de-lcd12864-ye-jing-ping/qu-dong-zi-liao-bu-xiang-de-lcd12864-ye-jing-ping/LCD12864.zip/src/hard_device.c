

#include "hard_device.h"


void portInit(unsigned char port){
	switch(port){
		case 0:
		{
			P0M0=0xff;
			P0M1=0x00;
			break;
		}
		case 1:
		{
			P1M0=0xff;
			P1M1=0x00;
			break;		
		}
		case 2:
		{
			P2M0=0xff;
			P2M1=0x00;
			break;		
		}
//		case 3:
//		{
//			P0M0=0xff;
//			P0M1=0x00;
//			break;		
//		}
//		case 4:
//		{
//		
//		}
	}
}
void pinInit(unsigned char port, unsigned char pin, unsigned char mode){
	switch(port){
		case 0:
		{
			P0M0 |= ((mode&0x01)<<pin);
			P0M1 |= (((mode&0x02)>>1)<<pin);
			break;
		}
		case 1:
		{
			P1M0 |= ((mode&0x01)<<pin);
			P1M1 |= (((mode&0x02)>>1)<<pin);
			break;		
		}
		case 2:
		{
			P2M0 |= ((mode&0x01)<<pin);
			P2M1 |= (((mode&0x02)>>1)<<pin);
			break;		
		}
		case 3:
		{
			P3M0 |= ((mode&0x01)<<pin);
			P3M1 |= (((mode&0x02)>>1)<<pin);
			break;		
		}
		case 4:
		{
			P4M0 |= ((mode&0x01)<<pin);
			P4M1 |= (((mode&0x02)>>1)<<pin);
			break;		
		}
	}
}
void Delay_us(unsigned int us)		//@22.1184MHz
{
	unsigned int i;
	for(i=0;i<us;i++) _nop_();

}
void Delay_ms(unsigned int ms)		//@22.1184MHz
{
	unsigned int i,j;
	for(i=0;i<ms;i++){
		for(j=0;j<1000;j++){
			_nop_();_nop_();
			_nop_();_nop_();
			_nop_();_nop_();
			_nop_();_nop_();
			_nop_();_nop_();
			
		}
	}
}	