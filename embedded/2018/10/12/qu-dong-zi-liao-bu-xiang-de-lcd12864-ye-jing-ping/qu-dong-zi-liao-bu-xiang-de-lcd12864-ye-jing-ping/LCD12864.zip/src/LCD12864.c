/**
*主控是ST7565
*
*
**/

#include "hard_device.h"
#include "LCD12864.h"
#include <stdio.h>
#include <string.h>

static void LCD_send(unsigned char value, unsigned char mode);
static unsigned char LCD_read(unsigned mode);
static void LCD_write8bits(unsigned char value);
static unsigned char LCD_read8bits(void);
static void LCD_pulseEnable();

#define DP				P2
											//				读显示数据	写显示数据	读状态	写命令
sbit LCD_A0 = P1^0;		//A0(RS),	1						1						0				0
sbit LCD_RW = P1^2;		//RW,			1						0						1				0
sbit LCD_EN = P1^1;		//EN,使能，高电平有效
sbit LCD_RST = P1^4;	//RST,复位，低电平有效
sbit LCD_CS = P1^3;		//CS,片选，低电平有效

static unsigned char displayFunction;
static unsigned char displayControl;
static unsigned char displayMode;

//static volatile unsigned char initialized;
static unsigned char lcdCol;
static unsigned char numLines;
static unsigned char rowOffsets[4];

void LCD_Init(void){
	LCD_RST=1;
	Delay_us(100);
	LCD_RST=0;
	Delay_us(100);
	LCD_RST=1;
	Delay_us(100);
	LCD_Command((LCD_SET_BIAS | LCD_BIAS_1_7)); 		//set lcd bias
	LCD_Command(LCD_SELECT_ADC_NORMAL);							//set lcd ADC
	LCD_Command((LCD_SELECT_COM_OUTPUT_MODE | LCD_COM_OUTPUT_MODE_NOR));
	LCD_Command(0x20);
	LCD_Command(LCD_NO_USE_VOL_MODE);	
	LCD_Command((LCD_SET_POWER_CONTROL|LCD_BOOSTER_CIRCUIT_OFF|
							 LCD_VOL_REG_CIRCUIT_ON|LCD_VOL_FOL_CIRCUIT_ON));
	LCD_Command(LCD_DISPLAY_ALL_POINT_ON);
	Delay_ms(5);
	LCD_Command(LCD_DISPLAY_ALL_POINT_OFF);
	Delay_ms(5);
}
    
void LCD_Begin(unsigned char cols, unsigned char lines){

	pinInit(0, 0, PIN_MODE_OP);
	portInit(1);
	portInit(2);

}

/********** high level commands, for the user! */
void LCD_DisplayChr(unsigned char col, unsigned char row, unsigned char value){
	LCD_SetCursor(col,row);
	LCD_Write(value);
}
void LCD_DisplayStr(unsigned char col, unsigned char row, unsigned char code* str){
//	unsigned char len=0;
//	col &= 0xf;
//	row &= 0x1;
//	while(str[len]>=0x20){
//		if(col<=0xf){
//			LCD_DisplayChr(col, row, str[len]);
//			len++;
//			col++;
//			//Delay_us(10);
//		}
//	}

	unsigned char i=0;
	while(str[i]>=0x20){
		LCD_DisplayChr(col+i, row, str[i]);
		Delay_us(10);
		if(i>(lcdCol-col) && ((numLines-row)>=1)){
			LCD_DisplayChr((i-lcdCol+col-1), row+1, str[i]);
			Delay_us(10);
		}
		i++;
	}
}

void LCD_Clear(void){

}
void LCD_Home(void){

}

void LCD_NoDisplay(void){

}
void LCD_Display(void){

}
void LCD_NoBlink(void){

}
void LCD_Blink(void){

}
void LCD_NoCursor(void){
 
}
void LCD_Cursor(void){

}
void LCD_ScrollDisplayLeft(void){

}
void LCD_ScrollDisplayRight(void){

}
void LCD_LeftToRight(void){
 
}
void LCD_RightToLeft(void){

}
void LCD_AutoScroll(void){

}
void LCD_NoAutoScroll(void){

}

void LCD_SetRowOffsets(int row1, int row2, int row3, int row4){

}
void LCD_CreateChar(unsigned char location, unsigned char charmap[]){

}
void LCD_SetCursor(unsigned char col, unsigned char row){

}
/*********** mid level commands, for sending data/cmds */
void LCD_Command(unsigned char value){
	LCD_send(value, W_COMMAND);
}
char LCD_Write(unsigned char value){
	LCD_send(value, W_DATA);
	return 1;
}
/************ low level data pushing commands **********/
static void LCD_send(unsigned char value, unsigned char mode){
	LCD_RW=1;
	LCD_CS=1;
	Delay_us(10);
	LCD_A0=mode;
	LCD_RW=0;
	LCD_CS=0;
	Delay_us(10);
	LCD_write8bits(value);
	Delay_us(10);
	LCD_CS=1;
	LCD_RW=1;
	LCD_A0=(!mode);
}
static unsigned char LCD_read(unsigned mode){
	unsigned char _data;
	LCD_RW=0;
	LCD_CS=1;
	Delay_us(10);
	LCD_A0=mode;
	LCD_RW=1;
	LCD_CS=0;
	Delay_us(10);
	_data=LCD_read8bits();
	Delay_us(10);
	LCD_CS=1;
	LCD_RW=0;
	LCD_A0=(!mode);
	return _data;
}
static void LCD_write8bits(unsigned char value){
	DP=value;
	LCD_pulseEnable();
}
static unsigned char LCD_read8bits(void){
	unsigned char _temp;
	LCD_EN=0;
	Delay_us(10);
	LCD_EN=1;
	_temp=DP;
	Delay_us(10);
	LCD_EN=0;
	Delay_us(10);
	return _temp;
}
static void LCD_pulseEnable(void){
	LCD_EN=0;
	Delay_us(10);
	LCD_EN=1;
	Delay_us(10);
	LCD_EN=0;
	Delay_us(10);
//	LCD_EN=1;
}
