

#include "hard_device.h"
#include "uart_hal.h"




void uartInit(char uartInstance, unsigned int baudRate, char mode){

	
}
void uartWriteChar(char chr){

	
}
void uartWriteStr(char* str){

	
}
void uartWriteHex(char hex){

	
}
	
void uartWriteInt(int int0){


}
